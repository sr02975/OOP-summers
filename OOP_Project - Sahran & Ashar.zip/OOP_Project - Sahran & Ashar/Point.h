#pragma once
//Point structure prototype
struct Point
{
	int x;
	int y;
	Point();
	Point(int, int);
};


