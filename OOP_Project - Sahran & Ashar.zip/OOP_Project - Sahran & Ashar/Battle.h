#pragma once

class Battle
{

};
